package com.sherlock.shoppingassist;


public class MemoData {
    String productName;
    int added;

    public MemoData(String a, int b){
        productName = a;
        added = b;
    }
}
